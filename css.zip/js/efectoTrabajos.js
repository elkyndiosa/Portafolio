// $(document).ready(function(){
//     $('.trabajo img').on('mouseover', function(){
//         $('.text-card').css({
//             'opacity': '1',
//             'transform': 'translate(0px, -68px)'
//         });
//         $('.trabajo img').css({
//             'opacity': '.5',
//             'transform': 'scale(1.5)'
//         });
//     });
//     $('.trabajo img').on('mouseout', function(){
//         $('.text-card').css({
//             'opacity': '0',
//             'transform': 'translate(0px, 0px)'
//         });
//         $('.trabajo img').css({
//             'opacity': '1',
//             'transform': 'scale(1)'
//         });
//     });
// });